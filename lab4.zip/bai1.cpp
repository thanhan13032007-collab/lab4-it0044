
#include <iostream>
using namespace std;

struct NODE {
    int info;
    NODE* pNext;
};


struct LIST {
    NODE* pHead;
    NODE* pTail;
};

void CreateEmptyList(LIST &L) {
    L.pHead = NULL;
    L.pTail = NULL;
}

NODE* CreateNode(int x) {
    NODE* p = new NODE;
    if (p == NULL)
        exit(1);
    p->info = x;
    p->pNext = NULL;
    return p;
}

void InsertTail(LIST &L, NODE* p) {
    if (L.pHead == NULL) {
        L.pTail = p;
        L.pHead = L.pTail;
    }
    else {
        L.pTail->pNext = p;
        L.pTail = p;
    }
}

void PrintList(LIST L)
{
    NODE *p = L.pHead;
    while (p != NULL)
    {
        cout << p->info << " ";
        p = p->pNext;
    }
}

// code 
void SwapPointers(LIST & L,NODE *p,NODE *node_min)
{
    NODE* bf_p = nullptr;
    NODE* bf_node_min = nullptr;
    NODE*q = L.pHead;

    while(q != nullptr)
    {
        if(q == p)
            break;
        bf_p = q;
        q = q->pNext;
    }
    q = L.pHead;
    while(q != nullptr)
    {
        if(q == node_min)
            break;
        bf_node_min = q;
        q = q->pNext;
    }
    if(bf_p != nullptr)
    {
        bf_p->pNext = node_min;
    }
    else 
        L.pHead = node_min;

    if(bf_node_min != nullptr)
    {
        bf_node_min->pNext = p;
    }
    else
        L.pHead = p;

    NODE* temp = p->pNext;
    p->pNext = node_min->pNext;
    node_min->pNext = temp;
    
    if(p->pNext == nullptr)
        L.pTail = p;
    else if (node_min->pNext == nullptr)
        L.pTail = node_min;
}
//code

void SelectionSort(LIST &L){
    NODE* tmp;
    NODE* p = L.pHead;
    NODE* q;
    NODE* node_min;
    while (p != NULL){
        node_min = p;
        for (q = p->pNext; q != NULL; q = q->pNext){
            if (q->info < node_min->info)
                node_min = q;
        }
        SwapPointers(L, p, node_min);
        p = node_min->pNext;
    }
}

int main()
{
    LIST L;
    CreateEmptyList(L);
    int n; cin >> n;
    int x;
    for (int i = 0; i < n; i++){
        cin >> x;
        InsertTail(L, CreateNode(x));
    }
    SelectionSort(L);
    PrintList(L);
    return 0;
}
